from numpy import arange
min = 1
low = 0
for p in arange(0,1,0.0001):
    t = (p/(10-20*p)) + ((1-p)/(15-20*(1-p)))
    if (t <= min) & (t > low):
        min = t
        answer = p;
print(answer)
